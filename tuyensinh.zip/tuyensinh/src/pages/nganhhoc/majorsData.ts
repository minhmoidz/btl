export const hotMajors = [
    { name: 'Ngành Khoa học máy tính', tag: 'HOT', slug: 'khoa-hoc-may-tinh' },
    { name: 'Ngành Công nghệ thông tin (C...', tag: 'HOT', slug: 'cong-nghe-thong-tin-c' },
    { name: 'Ngành Mạng máy tính và truyền...', tag: 'HOT', slug: 'mang-may-tinh-truyen-thong' },
    { name: 'Ngành Công nghệ thông tin', tag: 'HOT', slug: 'cong-nghe-thong-tin' },
  ];
  
  export const newMajors = [
    { name: 'Ngành Công nghệ thông tin (C...', tag: 'NEW', slug: 'cong-nghe-thong-tin-c' },
    { name: 'Ngành Mạng máy tính và truyề...', tag: 'NEW', slug: 'mang-may-tinh-truyen-thong' },
    { name: 'Ngành Kế toán chất lượng cao ...', tag: 'NEW', slug: 'ke-toan-chat-luong-cao' },
    { name: 'Ngành Công nghệ thông tin ...', tag: 'NEW', slug: 'cong-nghe-thong-tin' },
  ];
  