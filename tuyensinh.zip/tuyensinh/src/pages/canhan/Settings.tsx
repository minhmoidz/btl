import React from 'react';

const Settings: React.FC = () => {
  return (
    <div style={{ maxWidth: 600, margin: '50px auto', padding: 20 }}>
      <h1>Trang Cài đặt</h1>
      <p>Ở đây bạn có thể thêm các tùy chọn cấu hình cho ứng dụng.</p>
    </div>
  );
};

export default Settings;
