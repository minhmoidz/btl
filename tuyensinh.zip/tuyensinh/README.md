npm 
npm install @ant-design/v5-patch-for-react-19 --save

npm install axios   

npm install react-router-dom@6
npm install antd                                    


